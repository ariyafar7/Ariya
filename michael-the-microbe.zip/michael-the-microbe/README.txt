Michael the Microbe: an elgoog concept Doodle for World IBS Day (19 April).

To play offline: unzip this folder and open index.html in a web browser (Chrome, Edge, Safari or Firefox).
Keep soundtrack.mp3 in the same folder as index.html so the music plays.
An internet connection is only needed for the fonts and for the links on the end page.

University prototype (MEDN2002/DESN3010, UNSW). General health information, not medical advice.
